var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["f2c55077-a52b-4009-9747-6cf8922993b9","3b34ea2f-9143-4869-90de-9da226b264e7","407d2d67-422d-4a1e-bc6d-6000a90c3d7d","d4fa970c-22fe-4692-8101-5585d72499dd","68f31197-830e-411f-b07b-5f7c639672cf"],"propsByKey":{"f2c55077-a52b-4009-9747-6cf8922993b9":{"name":"pu1","sourceUrl":"assets/api/v1/animation-library/gamelab/0axN3iBEMlHDrHZLJ1cpNnuGmlPSl11_/category_faces/pupilportrait_02.png","frameSize":{"x":282,"y":391},"frameCount":1,"looping":true,"frameDelay":2,"version":"0axN3iBEMlHDrHZLJ1cpNnuGmlPSl11_","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":282,"y":391},"rootRelativePath":"assets/api/v1/animation-library/gamelab/0axN3iBEMlHDrHZLJ1cpNnuGmlPSl11_/category_faces/pupilportrait_02.png"},"3b34ea2f-9143-4869-90de-9da226b264e7":{"name":"u3","sourceUrl":"assets/api/v1/animation-library/gamelab/dHshQXiche2omlBhwWrKH5zbfEiC6doy/category_germs/virus03_11.png","frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"dHshQXiche2omlBhwWrKH5zbfEiC6doy","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dHshQXiche2omlBhwWrKH5zbfEiC6doy/category_germs/virus03_11.png"},"407d2d67-422d-4a1e-bc6d-6000a90c3d7d":{"name":"viru","sourceUrl":"assets/api/v1/animation-library/gamelab/84glPGNWF96yVw37ubRFQIYuIQYx80S4/category_germs/virus03_08.png","frameSize":{"x":388,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"84glPGNWF96yVw37ubRFQIYuIQYx80S4","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/84glPGNWF96yVw37ubRFQIYuIQYx80S4/category_germs/virus03_08.png"},"d4fa970c-22fe-4692-8101-5585d72499dd":{"name":"vi","sourceUrl":"assets/api/v1/animation-library/gamelab/7_fQFvQ9YjMoziYN80X0zhQJiJXHDA.t/category_germs/virus03_04.png","frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"7_fQFvQ9YjMoziYN80X0zhQJiJXHDA.t","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/7_fQFvQ9YjMoziYN80X0zhQJiJXHDA.t/category_germs/virus03_04.png"},"68f31197-830e-411f-b07b-5f7c639672cf":{"name":"vi0","sourceUrl":"assets/api/v1/animation-library/gamelab/jtYFwldEv_5qJnCT2glgiwdohYvywxlK/category_germs/virus03_02.png","frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"jtYFwldEv_5qJnCT2glgiwdohYvywxlK","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/jtYFwldEv_5qJnCT2glgiwdohYvywxlK/category_germs/virus03_02.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life 
 var man1,man2,man3,hero1,finish,qwe,qwer,dfg

hero=createSprite(200,360,100,50)
hero.setAnimation("pu1")
hero.scale=0.2
man1=createSprite(50,260,100,10)
man1.setAnimation("u3")
man1.scale=0.1
man2=createSprite(380,170,100,50)
man3=createSprite(50,100)
man3.setAnimation("viru")
man2.setAnimation("vi0")
man2.scale=0.1
man3.scale=0.1
finish=createSprite(200,10,250,10)
finish.shapeColor="blue"
dfg=createSprite(20,180,10,400)
qwer=createSprite(380,180,10,400)
dfg.shapeColor="red"
qwer.shapeColor="red"
  man1.velocityX=10
man2.velocityX=-10
man3.velocityX=10
  
  
  function draw() {
background("green")






createEdgeSprites()
man1.bounceOff(edges)
man2.bounceOff(edges)
man3.bounceOff(edges)

drawSprites()

if (keyDown("up")) 
  {
    hero.y=hero.y-3
  }
if (keyDown("down")) 
 {
   hero.y=hero.y+3
 } 

if (hero.isTouching(finish)) 
 {
  playSound("assets/category_points/vibrant_game_collect_jewel_1_down.mp3")
 } 
if (hero.isTouching(man1)) 
  {
  playSound("https://audio.code.org/winpoint2.mp3")   
   
  }

if (hero.isTouching(man3)) 
  {
  playSound("https://audio.code.org/winpoint2.mp3")
  }

if (hero.isTouching(man2)) 
  {
  playSound("https://audio.code.org/winpoint2.mp3")
  }

if (hero.isTouching(man1)) 
 {
   hero.x=200
   hero.y=360
   
 } 

if (hero.isTouching(man2)) 
 {
   hero.x=200
   hero.y=360
   
 } 


if (hero.isTouching(man3)) 
 {
   hero.x=200
   hero.y=360
   
 } 



}














































// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
